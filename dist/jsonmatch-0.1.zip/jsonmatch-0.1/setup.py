from distutils.core import setup

setup(name='jsonmatch',
      version='0.1',
      description='',
      author='Jason d\'Eon',
      author_email='jasonndeon@gmail.com',
      packages=['jsonmatch'],
      install_requires=[
        'numpy',
        'scipy',
        'nltk',
        'autocorrect',
        'mysql-connector-python-rf',
        'sshtunnel',
        'sklearn',
        'gensim',
        'autocomplete'
      ])